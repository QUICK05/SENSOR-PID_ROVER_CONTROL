// Includes ------------------------------------------------------------------
#include "main.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

// Private define ------------------------------------------------------------
#define LIS3DH_ADDR  0x18   // 7-bit address for LIS3DH (use (LIS3DH_ADDR << 1) in HAL functions)
#define LIS2MDL_ADDR 0x1E   // 7-bit address for LIS2MDL

// Define the tolerance for reaching the setpoint
#define THRESHOLD 3.0f      // Increased threshold to 2 degrees
#define MAX_INTEGRAL 100.0f // Anti-windup limit

// Define the gear ratio
#define GEAR_RATIO  (74.0f / 17.0f)

#define DESIRED_ANGLE1 90.0f
#define DESIRED_ELEVATION1 90.0f

// Define PWM values for servo control
#define PWM1_CW    1540  // Clockwise movement
#define PWM1_STOP  1478  // Stop position
#define PWM1_CCW   1416  // Counter-clockwise movement
#define PWM2_CW    1530
#define PWM2_STOP  1500
#define PWM2_CCW   1440

#define FILTER_SIZE 5

// Private variables ---------------------------------------------------------
I2C_HandleTypeDef hi2c1;
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;
DMA_HandleTypeDef hdma_tim1_ch1;
DMA_HandleTypeDef hdma_tim3_ch2;
DMA_HandleTypeDef hdma_tim3_ch1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

// Message buffer
char msg[1000];

// Calibration variables for magnetometer
float mag_offset_x = 0.0f;
float mag_offset_y = 0.0f;
float mag_offset_z = 0.0f;
float mag_scale_x = 1.0f;
float mag_scale_y = 1.0f;
float mag_scale_z = 1.0f;

float accel_offset_x = 0.0f;
float accel_offset_y = 0.0f;
float accel_offset_z = 0.0f;
float accel_scale_x = 1.0f;
float accel_scale_y = 1.0f;
float accel_scale_z = 1.0f;

// Sensor data variables
float x_accel = 0.0f, y_accel = 0.0f, z_accel = 0.0f, lis3dh_temp = 0.0f;
float x_mag = 0.0f, y_mag = 0.0f, z_mag = 0.0f, lis2mdl_temp = 0.0f;
float x_cal = 0.0f, y_cal = 0.0f, z_cal = 0.0f;  // Calibrated magnetometer values

float angle_history[FILTER_SIZE] = {0};
float elevation_history[FILTER_SIZE] = {0};
int angle_filter_index = 0;
int elevation_filter_index = 0;
float normalize_angle(float angle);
float normalize_elevation(float elevation);

// Reference angle for north and gravity
float north_reference_angle = 0.0f;
float gravity_reference_elevation = 0.0f;

// PID controller structures
// MAST MOTOR (Azimuth - servo1)
typedef struct {
    float Kp;        // Proportional gain
    float Ki;        // Integral gain
    float Kd;        // Derivative gain
    float setpoint;  // Target angle
    float prev_error;
    float integral;
    float output;
    float max_integral; // Anti-windup limit
} PID_Controller;

// PID controller instances
PID_Controller pid_azimuth;
PID_Controller pid_elevation;

// Function Prototypes
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
void Servo_Init(void);

// I2C and Sensor Functions
void scan_i2c_bus(void);
HAL_StatusTypeDef lis3dh_init(void);
HAL_StatusTypeDef lis2mdl_init(void);
HAL_StatusTypeDef lis3dh_read_all_axes(void);
HAL_StatusTypeDef lis2mdl_read_all_axes(void);
HAL_StatusTypeDef lis3dh_read_temperature(void);
HAL_StatusTypeDef lis2mdl_read_temperature(void);

// PID Control Functions
void PID_Init(PID_Controller *pid, float Kp, float Ki, float Kd, float setpoint, float max_integral);
float PID_Compute(PID_Controller *pid, float current_value, float *error_out);
uint32_t Calculate_Servo_PWM(float error, float pid_output, uint32_t stop_pwm, uint32_t cw_pwm, uint32_t ccw_pwm);

// Angle Calculation and Calibration Functions
float calculate_magnetometer_azimuth(float x, float y, float z);
float calculate_accelerometer_elevation(float x, float y, float z);
void calibrate_magnetometer(void);
void apply_mag_calibration(void);
void initialize_antenna_position(void);

// System status checks
bool is_at_setpoint(float current_value, float setpoint, float threshold);
bool check_motion_limits(float x_accel, float y_accel, float z_accel);

// Error handling
void Error_Handler(void);

/**
  * @brief  Initialize PID controller
  * @param  pid: Pointer to PID controller structure
  * @param  Kp: Proportional gain
  * @param  Ki: Integral gain
  * @param  Kd: Derivative gain
  * @param  setpoint: Target value
  * @param  max_integral: Anti-windup limit for integral term
  */
void PID_Init(PID_Controller *pid, float Kp, float Ki, float Kd, float setpoint, float max_integral) {
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->setpoint = setpoint;
    pid->prev_error = 0.0f;
    pid->integral = 0.0f;
    pid->output = 0.0f;
    pid->max_integral = max_integral;
}

/**
  * @brief  Compute PID output
  * @param  pid: Pointer to PID controller structure
  * @param  current_value: Current measurement
  * @param  error_out: Pointer to store error value
  * @retval PID output value
  */
float PID_Compute(PID_Controller *pid, float current_value, float *error_out) {
    float error = pid->setpoint - current_value;
    // Store the error value for the caller if requested
    if (error_out != NULL) {
    *error_out = error;
    }

    // Add deadband logic here
    if (fabs(error) < 1.0f) {  // Small deadband of 1 degree
    pid->integral = 0;      // Reset integral term to prevent wind-up
    return 0;               // Return zero output when very close to target
    }
    pid->integral += error;

    // Anti-windup - limit integral term
    if (pid->integral > pid->max_integral) pid->integral = pid->max_integral;
    if (pid->integral < -pid->max_integral) pid->integral = -pid->max_integral;

    float derivative = error - pid->prev_error;
    pid->output = pid->Kp * error + pid->Ki * pid->integral + pid->Kd * derivative;
    pid->prev_error = error;

    if (error_out != NULL) {
        *error_out = error;
    }

    return pid->output;
}

/**
  * @brief  Calculate servo PWM value based on error and PID output
  * @param  error: Current error (setpoint - current)
  * @param  pid_output: PID controller output
  * @param  stop_pwm: PWM value for stopped position
  * @param  cw_pwm: PWM value for clockwise movement
  * @param  ccw_pwm: PWM value for counter-clockwise movement
  * @retval PWM value to apply to servo
  */


// Rotate to align with magnetic north
void align_to_north(void) {
    float current_angle;
    float error;
    uint32_t servo_pwm = PWM1_STOP;
    bool aligned = false;
    uint32_t timeout_counter = 0;  // Add timeout for safety

    snprintf(msg, sizeof(msg), "Aligning antenna to magnetic north (%.1f°)...\r\n", north_reference_angle);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    // Wait for stabilization before starting alignment
    HAL_Delay(500);

    // Alignment loop
    while (!aligned && timeout_counter < 300) {  // Add timeout (30 seconds)
        lis2mdl_read_all_axes();
        apply_mag_calibration();
        current_angle = calculate_magnetometer_azimuth(x_mag, y_mag, z_mag);
        error = north_reference_angle - current_angle;

        // Normalize error to shortest path
        if (error > 180.0f) error -= 360.0f;
        if (error < -180.0f) error += 360.0f;

        if (fabs(error) < THRESHOLD) {
            servo_pwm = PWM1_STOP;
            aligned = true;
        } else if (fabs(error) < THRESHOLD * 1.5) {
            // Add a smaller PWM value when getting close to target
            if (error > 0) {
                servo_pwm = PWM1_STOP + 10; // Very gentle adjustment
            } else {
                servo_pwm = PWM1_STOP - 10; // Very gentle adjustment
            }
        } else if (error > 0) {
            servo_pwm = PWM1_CW;
        } else {
            servo_pwm = PWM1_CCW;
        }

        TIM3->CCR1 = servo_pwm;

        snprintf(msg, sizeof(msg), "Aligning: Angle=%.2f°, Target=%.2f°, Error=%.2f°, PWM=%lu\r\n",
                current_angle, north_reference_angle, error, (unsigned long)servo_pwm);
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

        HAL_Delay(100);
        timeout_counter++;
    }

    // Stop motor
    TIM3->CCR1 = PWM1_STOP;

    if (aligned) {
        snprintf(msg, sizeof(msg), "Aligned to north! Current position: %.2f°\r\n", current_angle);
    } else {
        snprintf(msg, sizeof(msg), "Alignment timeout. Best position: %.2f°\r\n", current_angle);
    }
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    // Stabilization delay
    HAL_Delay(1000);
}

void rotate_to_desired_angle(float target_angle, float *current_angle) {
    float error;
    uint32_t servo_pwm = PWM1_STOP;
    bool aligned = false;
    uint32_t timeout_counter = 0;
    target_angle = normalize_angle(target_angle);

    snprintf(msg, sizeof(msg), "Rotating to target angle %.1f°...\r\n", target_angle);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    if (HAL_OK == lis2mdl_read_all_axes()) {
        apply_mag_calibration();
        *current_angle = calculate_magnetometer_azimuth(x_mag, y_mag, z_mag);

        while (!aligned && timeout_counter < 500) {
            error = target_angle - *current_angle;

            // Normalize error for shortest path
            if (error > 180.0f) error -= 360.0f;
            if (error < -180.0f) error += 360.0f;

            if (fabs(error) < THRESHOLD) {
                servo_pwm = PWM1_STOP;
                aligned = true;
            } else if (error > 0) {
                servo_pwm = PWM1_CW;
            } else {
                servo_pwm = PWM1_CCW;
            }

            TIM3->CCR1 = servo_pwm;

            snprintf(msg, sizeof(msg), "Rotating: Angle=%.2f°, Target=%.2f°, Error=%.2f°\r\n",
                    *current_angle, target_angle, error);
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

            HAL_Delay(100);

            lis2mdl_read_all_axes();
            apply_mag_calibration();
            *current_angle = calculate_magnetometer_azimuth(x_mag, y_mag, z_mag);

            timeout_counter++;
        }

        if (fabs(error) < THRESHOLD * 2) {
            // When getting close, pause briefly to let it settle
            TIM3->CCR1 = PWM1_STOP;
            HAL_Delay(100);

            // Re-read position after settling
            lis2mdl_read_all_axes();
            apply_mag_calibration();
            *current_angle = calculate_magnetometer_azimuth(x_mag, y_mag, z_mag);
            error = target_angle - *current_angle;

            // Normalize error for shortest path
            if (error > 180.0f) error -= 360.0f;
            if (error < -180.0f) error += 360.0f;
        }
        TIM3->CCR1 = PWM1_STOP;

        if (aligned) {
                    snprintf(msg, sizeof(msg), "Target acquired! Position: %.2f°\r\n", *current_angle);
                } else {
                    snprintf(msg, sizeof(msg), "Rotation timeout. Best position: %.2f°\r\n", *current_angle);
                }
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            }

            HAL_Delay(500);
        }

uint32_t Calculate_Servo_PWM(float error, float pid_output, uint32_t stop_pwm, uint32_t cw_pwm, uint32_t ccw_pwm) {
    uint32_t pwm_value;

    if (fabs(error) < THRESHOLD) {
        // Within threshold, stop movement
        pwm_value = stop_pwm;
    } else if (error > 0) {
        // Need to move clockwise
        pwm_value = stop_pwm + (uint32_t)(fabs(pid_output));
        if (pwm_value > cw_pwm) pwm_value = cw_pwm;
    } else {
        // Need to move counter-clockwise
        pwm_value = stop_pwm - (uint32_t)(fabs(pid_output));
        if (pwm_value < ccw_pwm) pwm_value = ccw_pwm;
    }

    return pwm_value;
}

/**
  * @brief  Calculate azimuth angle from magnetometer readings
  * @param  x: X-axis magnetometer reading
  * @param  y: Y-axis magnetometer reading
  * @param  z: Z-axis magnetometer reading
  * @retval Azimuth angle in degrees
  */
float calculate_magnetometer_azimuth(float x, float y, float z) {
    // Apply calibration
    float x_calibrated = (x - mag_offset_x) * mag_scale_x;
    float z_calibrated = (z - mag_offset_z) * mag_scale_z;

    // Calculate angle in XZ plane (azimuth)
    float angle = atan2(z_calibrated, x_calibrated) * (180.0f / M_PI);

    // Convert to 0-360 degrees compass heading
    // In standard compass, 0° is north, 90° is east, 180° is south, 270° is west
    return normalize_angle(90.0f - angle);  // This gives standard compass heading
}

/**
  * @brief  Calculate elevation angle from magnetometer readings
  * @param  x: X-axis magnetometer reading
  * @param  y: Y-axis magnetometer reading
  * @param  z: Z-axis magnetometer reading
  * @retval Elevation angle in degrees
  */
float calculate_accelerometer_elevation(float x, float y, float z) {
    // Apply calibration
    float x_cal = (x - accel_offset_x) * accel_scale_x;
    float y_cal = (y - accel_offset_y) * accel_scale_y;
    float z_cal = (z - accel_offset_z) * accel_scale_z;

    // Calculate pitch angle (elevation)
    float elevation = atan2(-y_cal, sqrt(x_cal*x_cal + z_cal*z_cal)) * (180.0f / M_PI);

    return normalize_elevation(0.0f - elevation);
}

float filter_angle(float new_angle) {
    // Handle angle wrapping (e.g., 359° to 1° transition)
    for (int i = 0; i < FILTER_SIZE; i++) {
        if (fabs(angle_history[i] - new_angle) > 180.0f) {
            // Adjust the angle to prevent averaging errors across the 0/360 boundary
            if (angle_history[i] > 180.0f && new_angle < 180.0f) {
                new_angle += 360.0f;
            } else if (angle_history[i] < 180.0f && new_angle > 180.0f) {
                new_angle -= 360.0f;
            }
        }
    }

    // Add new value to history
    angle_history[angle_filter_index] = new_angle;
    angle_filter_index = (angle_filter_index + 1) % FILTER_SIZE;

    // Calculate average with weighting (newer samples have more weight)
    float sum = 0;
    float weight_sum = 0;
    for (int i = 0; i < FILTER_SIZE; i++) {
        int age = (angle_filter_index - i + FILTER_SIZE) % FILTER_SIZE;
        float weight = FILTER_SIZE - age;
        sum += angle_history[i] * weight;
        weight_sum += weight;
    }

    float result = sum / weight_sum;
    // Normalize result back to 0-360 range
    return normalize_angle(result);
}

float filter_elevation(float new_elevation) {
    elevation_history[elevation_filter_index] = new_elevation;
    elevation_filter_index = (elevation_filter_index + 1) % FILTER_SIZE;

    // Calculate average
    float sum = 0;
    for (int i = 0; i < FILTER_SIZE; i++) {
        sum += elevation_history[i];
    }
    return sum / FILTER_SIZE;
}
/**
  * @brief  Apply magnetometer calibration to readings
  */
void apply_mag_calibration(void) {
    x_cal = (x_mag - mag_offset_x) * mag_scale_x;
    y_cal = (y_mag - mag_offset_y) * mag_scale_y;
    z_cal = (z_mag - mag_offset_z) * mag_scale_z;
}

void apply_accel_calibration(void) {
    // Apply offsets and scaling to raw accelerometer data
    x_accel = (x_accel - accel_offset_x) * accel_scale_x;
    y_accel = (y_accel - accel_offset_y) * accel_scale_y;
    z_accel = (z_accel - accel_offset_z) * accel_scale_z;
}


/**
  * @brief  Perform magnetometer calibration
  */
void calibrate_system(void) {
    // Display instructions
    snprintf(msg, sizeof(msg), "Starting automated system calibration...\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    // Variables for calibration
    float min_x_m = 1000.0f, max_x_m = -1000.0f;
    float min_y_m = 1000.0f, max_y_m = -1000.0f;
    float min_z_m = 1000.0f, max_z_m = -1000.0f;

    float min_x_a = 1000.0f, max_x_a = -1000.0f;
    float min_y_a = 1000.0f, max_y_a = -1000.0f;
    float min_z_a = 1000.0f, max_z_a = -1000.0f;

    // First, rotate clockwise for 5 seconds to collect calibration data
    snprintf(msg, sizeof(msg), "Rotating mast and box clockwise for calibration...\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    TIM3->CCR1 = PWM1_CW;
    TIM3->CCR2 = PWM2_CW;
    uint32_t start_time = HAL_GetTick();

    // Collect data during rotation
    while (HAL_GetTick() - start_time < 5000) {
        HAL_StatusTypeDef mag_status = lis2mdl_read_all_axes();
        HAL_StatusTypeDef accel_status = lis3dh_read_all_axes();

        if (mag_status == HAL_OK) {
            // Update magnetometer min/max values
            if (x_mag < min_x_m) min_x_m = x_mag;
            if (x_mag > max_x_m) max_x_m = x_mag;
            if (y_mag < min_y_m) min_y_m = y_mag;
            if (y_mag > max_y_m) max_y_m = y_mag;
            if (z_mag < min_z_m) min_z_m = z_mag;
            if (z_mag > max_z_m) max_z_m = z_mag;
        }

        if (accel_status == HAL_OK) {
            // Update accelerometer min/max values
            if (x_accel < min_x_a) min_x_a = x_accel;
            if (x_accel > max_x_a) max_x_a = x_accel;
            if (y_accel < min_y_a) min_y_a = y_accel;
            if (y_accel > max_y_a) max_y_a = y_accel;
            if (z_accel < min_z_a) min_z_a = z_accel;
            if (z_accel > max_z_a) max_z_a = z_accel;
        }

        // Progress indicator
        if ((HAL_GetTick() - start_time) % 1000 < 20) {
            snprintf(msg, sizeof(msg), ".");
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        }

        HAL_Delay(20);
    }

    // Stop rotation
    TIM3->CCR1 = PWM1_STOP;
    TIM3->CCR2 = PWM2_STOP;
    HAL_Delay(500);

    // Now rotate counter-clockwise for another 5 seconds
    snprintf(msg, sizeof(msg), "\r\nRotating counter-clockwise for calibration...\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    TIM3->CCR1 = PWM1_CCW;
    TIM3->CCR2 = PWM2_CCW;
    start_time = HAL_GetTick();

    // Continue collecting data
    while (HAL_GetTick() - start_time < 5000) {
        HAL_StatusTypeDef mag_status = lis2mdl_read_all_axes();
        HAL_StatusTypeDef accel_status = lis3dh_read_all_axes();

        if (mag_status == HAL_OK) {
            // Update magnetometer min/max values
            if (x_mag < min_x_m) min_x_m = x_mag;
            if (x_mag > max_x_m) max_x_m = x_mag;
            if (y_mag < min_y_m) min_y_m = y_mag;
            if (y_mag > max_y_m) max_y_m = y_mag;
            if (z_mag < min_z_m) min_z_m = z_mag;
            if (z_mag > max_z_m) max_z_m = z_mag;
        }

        if (accel_status == HAL_OK) {
            // Update accelerometer min/max values
            if (x_accel < min_x_a) min_x_a = x_accel;
            if (x_accel > max_x_a) max_x_a = x_accel;
            if (y_accel < min_y_a) min_y_a = y_accel;
            if (y_accel > max_y_a) max_y_a = y_accel;
            if (z_accel < min_z_a) min_z_a = z_accel;
            if (z_accel > max_z_a) max_z_a = z_accel;
        }

        // Progress indicator
        if ((HAL_GetTick() - start_time) % 1000 < 20) {
            snprintf(msg, sizeof(msg), ".");
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        }

        HAL_Delay(20);
    }

    // Stop rotation
    TIM3->CCR1 = PWM1_STOP;
    TIM3->CCR2 = PWM2_STOP;

    // Calculate offsets and scale factors
    mag_offset_x = (min_x_m + max_x_m) / 2.0f;
    mag_offset_y = (min_y_m + max_y_m) / 2.0f;
    mag_offset_z = (min_z_m + max_z_m) / 2.0f;
    accel_offset_x = (min_x_a + max_x_a) / 2.0f;
    accel_offset_y = (min_y_a + max_y_a) / 2.0f;
    accel_offset_z = (min_z_a + max_z_a) / 2.0f;

    float range_x_m = (max_x_m - min_x_m) / 2.0f;
    float range_y_m = (max_y_m - min_y_m) / 2.0f;
    float range_z_m = (max_z_m - min_z_m) / 2.0f;
    float avg_range_m = (range_x_m + range_y_m + range_z_m) / 3.0f;

    float range_x_a = (max_x_a - min_x_a) / 2.0f;
    float range_y_a = (max_y_a - min_y_a) / 2.0f;
    float range_z_a = (max_z_a - min_z_a) / 2.0f;
    float avg_range_a = (range_x_a + range_y_a + range_z_a) / 3.0f;

    mag_scale_x = (range_x_m > 0.0001f) ? (avg_range_m / range_x_m) : 1.0f;
    mag_scale_y = (range_y_m > 0.0001f) ? (avg_range_m / range_y_m) : 1.0f;
    mag_scale_z = (range_z_m > 0.0001f) ? (avg_range_m / range_z_m) : 1.0f;
    accel_scale_x = (range_x_a > 0.0001f) ? (avg_range_a / range_x_a) : 1.0f;
    accel_scale_y = (range_y_a > 0.0001f) ? (avg_range_a / range_y_a) : 1.0f;
    accel_scale_z = (range_z_a > 0.0001f) ? (avg_range_a / range_z_a) : 1.0f;

    // Display calibration results
    snprintf(msg, sizeof(msg), "\r\nCalibration complete!\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    snprintf(msg, sizeof(msg), "Magnetometer offsets: X=%.3f, Y=%.3f, Z=%.3f\r\n",
             mag_offset_x, mag_offset_y, mag_offset_z);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    snprintf(msg, sizeof(msg), "Magnetometer scale factors: X=%.3f, Y=%.3f, Z=%.3f\r\n",
             mag_scale_x, mag_scale_y, mag_scale_z);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    snprintf(msg, sizeof(msg), "Accelerometer offsets: X=%.3f, Y=%.3f, Z=%.3f\r\n",
             accel_offset_x, accel_offset_y, accel_offset_z);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    snprintf(msg, sizeof(msg), "Accelerometer scale factors: X=%.3f, Y=%.3f, Z=%.3f\r\n",
             accel_scale_x, accel_scale_y, accel_scale_z);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
}


float find_magnetic_north(void) {
    float north_angle = 0.0f;
    float max_field_strength = 0.0f;  // Changed from min to max

    snprintf(msg, sizeof(msg), "Finding magnetic north...\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    // Rotate full 360 degrees to find north
    TIM3->CCR1 = PWM1_CW;
    uint32_t start_time = HAL_GetTick();

    while (HAL_GetTick() - start_time < 10000) {  // 10 seconds for full rotation
        if (HAL_OK == lis2mdl_read_all_axes()) {
            apply_mag_calibration();

            // Calculate horizontal field strength
            float h_strength = sqrt(x_cal*x_cal + z_cal*z_cal);

            // North is where horizontal field is STRONGEST (not weakest)
            if (h_strength > max_field_strength) {  // Changed comparison
                max_field_strength = h_strength;
                north_angle = calculate_magnetometer_azimuth(x_mag, y_mag, z_mag);

                snprintf(msg, sizeof(msg), "Current north candidate: %.1f° (field: %.4f)\r\n",
                         north_angle, max_field_strength);
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            }
        }
        HAL_Delay(50);
    }

    // Stop rotation
    TIM3->CCR1 = PWM1_STOP;
    HAL_Delay(500);  // Add stable delay before returning

    snprintf(msg, sizeof(msg), "Magnetic north found at: %.1f°\r\n", north_angle);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    return north_angle;
}

float find_elevation_gravity(void) {
	float gravity_elevation = 9.81f;
	float max_field_strength = 9.81f;
    snprintf(msg, sizeof(msg), "Finding gravity elevation...\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    // Rotate full 360 degrees to find north
    TIM3->CCR2 = PWM2_CW;
    uint32_t start_time = HAL_GetTick();

    while (HAL_GetTick() - start_time < 10000) {  // 10 seconds for full rotation
        if (HAL_OK == lis3dh_read_all_axes()) {
            apply_accel_calibration();

            // Calculate horizontal field strength
            float h_strength = sqrt(x_accel*x_accel + z_accel*z_accel);

            // North is where horizontal field is STRONGEST (not weakest)
            if (h_strength > max_field_strength) {  // Changed comparison
                max_field_strength = h_strength;
                gravity_elevation = calculate_accelerometer_elevation(x_accel, y_accel, z_accel);

                snprintf(msg, sizeof(msg), "Current gravity candidate: %.1f° (field: %.4f)\r\n",
                         gravity_elevation, max_field_strength);
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            }
        }
        HAL_Delay(50);
    }

    // Stop rotation
    TIM3->CCR2 = PWM2_STOP;
    HAL_Delay(500);  // Add stable delay before returning

    snprintf(msg, sizeof(msg), "Gravity elevation found at: %.1f°\r\n", gravity_elevation);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    return gravity_elevation;
}


/**
  * @brief  Initialize antenna position by aligning to reference angle (0 degrees)
  */
void initialize_antenna_position(void) {
    float current_angle = 0.0f;
    float error = 0.0f;
    uint32_t servo_pwm = PWM1_STOP;
    bool aligned = false;
    uint32_t timeout_counter = 0;

    snprintf(msg, sizeof(msg), "\r\n--- Initializing antenna orientation ---\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    // Read initial magnetometer data
    if (HAL_OK == lis2mdl_read_all_axes()) {
        apply_mag_calibration();
        current_angle = calculate_magnetometer_azimuth(x_mag, y_mag, z_mag);

        snprintf(msg, sizeof(msg), "Initial position: %.2f°\r\n", current_angle);
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

        // Alignment loop - stops when error is below threshold or after timeout
        while (!aligned && timeout_counter < 300) { // Max 30 seconds (300 * 100ms)
            // Calculate error relative to 0°
            error = 0.0f - current_angle;

            // Adjust PWM based on error
            if (fabs(error) < THRESHOLD) {
                servo_pwm = PWM1_STOP;
                aligned = true;
            } else if (error > 0) {
                // Clockwise rotation
                servo_pwm = PWM1_CW;
            } else {
                // Counter-clockwise rotation
                servo_pwm = PWM1_CCW;
            }

            // Apply PWM
            TIM3->CCR1 = servo_pwm;

            // Display information
            snprintf(msg, sizeof(msg), "Aligning: Angle=%.2f°, Error=%.2f°, PWM=%lu\r\n",
                    current_angle, error, (unsigned long)servo_pwm);
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

            // Short delay
            HAL_Delay(100);

            // Read magnetometer again
            lis2mdl_read_all_axes();
            apply_mag_calibration();
            current_angle = calculate_magnetometer_azimuth(x_mag, y_mag, z_mag);

            // Increment timeout counter
            timeout_counter++;
        }

        // Stop motor
        TIM3->CCR1 = PWM1_STOP;

        if (aligned) {
            snprintf(msg, sizeof(msg), "Alignment successful! Position: %.2f°\r\n", current_angle);
        } else {
            snprintf(msg, sizeof(msg), "Alignment timeout. Final position: %.2f°\r\n", current_angle);
        }
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    } else {
        snprintf(msg, sizeof(msg), "Failed: Magnetometer not initialized.\r\n");
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    }

    // Stabilization delay
    HAL_Delay(500);
}

// Add this function to normalize angles to the -180° to +180° range.
float normalize_angle(float angle) {
    // Convert to 0-360 range
    while (angle < 0.0f)
        angle += 360.0f;
    while (angle >= 360.0f)
        angle -= 360.0f;
    return angle;
}

float normalize_elevation(float elevation) {
    // Normalize to the range of -180 to +180 degrees
    while (elevation > 180.0f)
        elevation -= 360.0f;
    while (elevation < -180.0f)
        elevation += 360.0f;
    return elevation;
}
/**
  * @brief  Check if current value is within threshold of setpoint
  * @param  current_value: Current measured value
  * @param  setpoint: Target value
  * @param  threshold: Acceptable error threshold
  * @retval true if within threshold, false otherwise
  */
bool is_at_setpoint(float current_value, float setpoint, float threshold) {
    return fabs(current_value - setpoint) <= threshold;
}

/**
  * @brief  Check if acceleration is within safe limits
  * @param  x_accel: X-axis acceleration in g
  * @param  y_accel: Y-axis acceleration in g
  * @param  z_accel: Z-axis acceleration in g
  * @retval true if within limits, false otherwise
  */
bool check_motion_limits(float x_accel, float y_accel, float z_accel) {
    // Calculate magnitude of acceleration
    float accel_magnitude = sqrt(x_accel*x_accel + y_accel*y_accel + z_accel*z_accel);

    // Define maximum allowable acceleration - increase tolerance
    float max_accel = 2.5f;  // in g

    // Add rate-of-change detection
    static float prev_magnitude = 0;
    float rate_of_change = fabs(accel_magnitude - prev_magnitude);
    prev_magnitude = accel_magnitude;

    return (accel_magnitude <= max_accel) && (rate_of_change < 0.5f);
}

/**
  * @brief  Scan I2C bus for connected devices
  */
void scan_i2c_bus(void) {
    HAL_StatusTypeDef status;
    uint8_t address;

    snprintf(msg, sizeof(msg), "Scanning I2C bus...\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    for(address = 1; address < 128; address++) {
        // Shift address by 1 bit as required by HAL functions
        status = HAL_I2C_IsDeviceReady(&hi2c1, (uint16_t)(address << 1), 2, 100);
        if (status == HAL_OK) {
            snprintf(msg, sizeof(msg), "Device found at address: 0x%02X\r\n", address);
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        }
    }

    snprintf(msg, sizeof(msg), "I2C scan complete\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
}

/**
  * @brief  Initialize the LIS3DH accelerometer sensor
  * @retval HAL_StatusTypeDef: Status (HAL_OK if successful)
  */
HAL_StatusTypeDef lis3dh_init(void) {
    uint8_t buf[2];
    HAL_StatusTypeDef status;

    // Configure CTRL_REG1: Enable XYZ, normal mode, 1.344 kHz data rate
    buf[0] = 0x20;  // CTRL_REG1 address
    buf[1] = 0x97;  // 0x97: enable normal mode, 1.344 kHz data rate
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 1000);
    if (status != HAL_OK) return status;

    // Configure CTRL_REG4: Enable block data update
    buf[0] = 0x23;  // CTRL_REG4 address
    buf[1] = 0x80;  // Enable block data update
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 1000);
    if (status != HAL_OK) return status;

    // Enable temperature sensor
    buf[0] = 0x1F;  // TEMP_CFG_REG address
    buf[1] = 0xC0;  // Enable temperature sensor
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS3DH_ADDR << 1), buf, 2, 1000);
    if (status != HAL_OK) return status;

    // Verify device ID
    uint8_t whoami;
    status = HAL_I2C_Mem_Read(&hi2c1, (LIS3DH_ADDR << 1), 0x0F, I2C_MEMADD_SIZE_8BIT, &whoami, 1, 1000);

    snprintf(msg, sizeof(msg), "LIS3DH WHO_AM_I: 0x%02X (expected: 0x33)\r\n", whoami);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    if (status != HAL_OK) return status;

    // Verify correct device ID
    if (whoami != 0x33) {
        return HAL_ERROR;
    }

    return HAL_OK;
}

/**
  * @brief  Read all accelerometer axes in one transaction
  * @retval HAL_StatusTypeDef: Status (HAL_OK if successful)
  */
HAL_StatusTypeDef lis3dh_read_all_axes(void) {
    uint8_t data[6];
    HAL_StatusTypeDef status;

    // Read all 6 bytes at once (X, Y, Z) with auto-increment
    status = HAL_I2C_Mem_Read(&hi2c1, (LIS3DH_ADDR << 1), 0x28 | 0x80, I2C_MEMADD_SIZE_8BIT, data, 6, 1000);
    if (status != HAL_OK) return status;

    // Assemble 16-bit values for each axis
    int16_t raw_x = (data[1] << 8) | data[0];
    int16_t raw_y = (data[3] << 8) | data[2];
    int16_t raw_z = (data[5] << 8) | data[4];

    // Convert to g values (±2g range, 16-bit resolution)
    float sensitivity = 0.004f;  // g per LSB
    x_accel = raw_x * sensitivity;
    y_accel = raw_y * sensitivity;
    z_accel = raw_z * sensitivity;

    return HAL_OK;
}

/**
  * @brief  Read LIS3DH temperature sensor
  * @retval HAL_StatusTypeDef: Status (HAL_OK if successful)
  */
HAL_StatusTypeDef lis3dh_read_temperature(void) {
    uint8_t data[2];
    HAL_StatusTypeDef status;

    // Read temperature registers
    status = HAL_I2C_Mem_Read(&hi2c1, (LIS3DH_ADDR << 1), 0x0C, I2C_MEMADD_SIZE_8BIT, &data[0], 1, 1000);
    if (status != HAL_OK) return status;

    status = HAL_I2C_Mem_Read(&hi2c1, (LIS3DH_ADDR << 1), 0x0D, I2C_MEMADD_SIZE_8BIT, &data[1], 1, 1000);
    if (status != HAL_OK) return status;

    // Convert to temperature (LIS3DH-specific calculation)
    int16_t raw_temp = (data[1] << 8) | data[0];
    lis3dh_temp = raw_temp / 64.0f;  // Simplified conversion

    return HAL_OK;
}

/**
  * @brief  Initialize the LIS2MDL magnetometer
  * @retval HAL_StatusTypeDef: Status (HAL_OK if successful)
  */
HAL_StatusTypeDef lis2mdl_init(void) {
    uint8_t buf[2];
    HAL_StatusTypeDef status;

    // Verify WHO_AM_I first
    uint8_t whoami;
    status = HAL_I2C_Mem_Read(&hi2c1, (LIS2MDL_ADDR << 1), 0x4F, I2C_MEMADD_SIZE_8BIT, &whoami, 1, 1000);

    snprintf(msg, sizeof(msg), "LIS2MDL WHO_AM_I: 0x%02X (expected: 0x40)\r\n", whoami);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    if (status != HAL_OK) return status;

    if (whoami != 0x40) {
        snprintf(msg, sizeof(msg), "LIS2MDL returned incorrect WHO_AM_I value\r\n");
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        return HAL_ERROR;
    }

    // Configure CFG_REG_A: Enable temperature compensation, continuous mode (10Hz)
    buf[0] = 0x60;  // CFG_REG_A address
    buf[1] = 0x80;  // 0x80: temp comp enabled, continuous mode
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS2MDL_ADDR << 1), buf, 2, 1000);
    if (status != HAL_OK) return status;

    // Configure CFG_REG_C: Enable data-ready interrupt
    buf[0] = 0x62;  // CFG_REG_C address
    buf[1] = 0x01;  // DRDY_on_PIN enabled
    status = HAL_I2C_Master_Transmit(&hi2c1, (LIS2MDL_ADDR << 1), buf, 2, 1000);
    if (status != HAL_OK) return status;

    // Verify CFG_REG_A was set correctly
    uint8_t reg_value;
    status = HAL_I2C_Mem_Read(&hi2c1, (LIS2MDL_ADDR << 1), 0x60, I2C_MEMADD_SIZE_8BIT, &reg_value, 1, 1000);

    snprintf(msg, sizeof(msg), "LIS2MDL CFG_REG_A: 0x%02X (expected: 0x80)\r\n", reg_value);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    return status;
}

/**
  * @brief  Read all magnetometer axes
  * @retval HAL_StatusTypeDef: Status (HAL_OK if successful)
  */
HAL_StatusTypeDef lis2mdl_read_all_axes(void) {
    uint8_t data[6];
    HAL_StatusTypeDef status;

    // Check if data is ready
    uint8_t status_reg;
    status = HAL_I2C_Mem_Read(&hi2c1, (LIS2MDL_ADDR << 1), 0x67, I2C_MEMADD_SIZE_8BIT, &status_reg, 1, 1000);
    if (status != HAL_OK) return status;

    // Read all axes data (OUTX_L to OUTZ_H) in one transaction
    status = HAL_I2C_Mem_Read(&hi2c1, (LIS2MDL_ADDR << 1), 0x68, I2C_MEMADD_SIZE_8BIT, data, 6, 1000);
    if (status != HAL_OK) return status;

    // Assemble 16-bit values
    int16_t raw_x = (data[1] << 8) | data[0];
    int16_t raw_y = (data[3] << 8) | data[2];
    int16_t raw_z = (data[5] << 8) | data[4];

    // Convert to gauss values (1.5 mgauss/LSB = 0.0015 gauss/LSB)
    float sensitivity = 0.0015f;  // gauss per LSB
    x_mag = raw_x * sensitivity;
    y_mag = raw_y * sensitivity;
    z_mag = raw_z * sensitivity;

    return HAL_OK;
}

/**
  * @brief  Read LIS2MDL temperature sensor
  * @retval HAL_StatusTypeDef: Status (HAL_OK if successful)
  */
HAL_StatusTypeDef lis2mdl_read_temperature(void) {
    uint8_t data[2];
    HAL_StatusTypeDef status;

    // Read temperature registers
    status = HAL_I2C_Mem_Read(&hi2c1, (LIS2MDL_ADDR << 1), 0x6E, I2C_MEMADD_SIZE_8BIT, &data[0], 1, 1000);
    if (status != HAL_OK) return status;

    status = HAL_I2C_Mem_Read(&hi2c1, (LIS2MDL_ADDR << 1), 0x6F, I2C_MEMADD_SIZE_8BIT, &data[1], 1, 1000);
    if (status != HAL_OK) return status;

    // Convert to temperature (LIS2MDL-specific calculation)
    int16_t raw_temp = (data[1] << 8) | data[0];
    lis2mdl_temp = raw_temp * 0.125f;  // 8 LSB/°C = 0.125 °C/LSB

    return HAL_OK;
}

/**
  * @brief  System Clock Configuration
  */
void SystemClock_Config(void) {
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
    RCC_OscInitStruct.PLL.PLLN = 8;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) {
        Error_Handler();
    }
}

/**
  * @brief  Initialize I2C1 peripheral
  */
static void MX_I2C1_Init(void) {
    hi2c1.Instance = I2C1;
    hi2c1.Init.Timing = 0x10B17DB5;
    hi2c1.Init.OwnAddress1 = 0;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2 = 0;
    hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c1) != HAL_OK) {
        Error_Handler();
    }
    if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK) {
        Error_Handler();
    }
    if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK) {
        Error_Handler();
    }
}

/**
  * @brief  Initialize TIM1 peripheral for PWM output
  */
static void MX_TIM1_Init(void) {
    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};
    TIM_OC_InitTypeDef sConfigOC = {0};
    TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

    htim1.Instance = TIM1;
    htim1.Init.Prescaler = 63;
    htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim1.Init.Period = 65535;
    htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim1.Init.RepetitionCounter = 0;
    htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&htim1) != HAL_OK) {
        Error_Handler();
    }
    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
    if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK) {
        Error_Handler();
    }
    if (HAL_TIM_PWM_Init(&htim1) != HAL_OK) {
        Error_Handler();
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK) {
        Error_Handler();
    }
    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = 0;
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
    sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
    sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
    if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK) {
        Error_Handler();
    }
    sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
    sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
    sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
    sBreakDeadTimeConfig.DeadTime = 0;
    sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
    sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
    sBreakDeadTimeConfig.BreakFilter = 0;
    sBreakDeadTimeConfig.BreakAFMode = TIM_BREAK_AFMODE_INPUT;
    sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
    sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
    sBreakDeadTimeConfig.Break2Filter = 0;
    sBreakDeadTimeConfig.Break2AFMode = TIM_BREAK_AFMODE_INPUT;
    sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
    if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK) {
        Error_Handler();
    }
    HAL_TIM_MspPostInit(&htim1);
}

/**
  * @brief  Initialize TIM3 peripheral for servo control
  */
static void MX_TIM3_Init(void) {
    TIM_MasterConfigTypeDef sMasterConfig = {0};
    TIM_OC_InitTypeDef sConfigOC = {0};

    htim3.Instance = TIM3;
    htim3.Init.Prescaler = 64 - 1;
    htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim3.Init.Period = 20000 - 1;
    htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_PWM_Init(&htim3) != HAL_OK) {
        Error_Handler();
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK) {
        Error_Handler();
    }
    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = 0;
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
    if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK) {
        Error_Handler();
    }
    if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK) {
        Error_Handler();
    }
    HAL_TIM_MspPostInit(&htim3);
}

/**
  * @brief  Initialize USART2 peripheral
  */
static void MX_USART2_UART_Init(void) {
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 115200;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
    huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    if (HAL_UART_Init(&huart2) != HAL_OK) {
        Error_Handler();
    }
    if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK) {
        Error_Handler();
    }
    if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK) {
        Error_Handler();
    }
    if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK) {
        Error_Handler();
    }
}

/**
  * @brief  Initialize USART3 peripheral for debug messages
  */
static void MX_USART3_UART_Init(void) {
    huart3.Instance = USART3;
    huart3.Init.BaudRate = 115200;
    huart3.Init.WordLength = UART_WORDLENGTH_8B;
    huart3.Init.StopBits = UART_STOPBITS_1;
    huart3.Init.Parity = UART_PARITY_NONE;
    huart3.Init.Mode = UART_MODE_TX_RX;
    huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart3.Init.OverSampling = UART_OVERSAMPLING_16;
    huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
    huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    if (HAL_UART_Init(&huart3) != HAL_OK) {
        Error_Handler();
    }
}

/**
  * @brief  Initialize DMA controller
  */
static void MX_DMA_Init(void) {
    __HAL_RCC_DMA1_CLK_ENABLE();
    HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
    HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);
}

/**
  * @brief  Initialize GPIO pins
  */
static void MX_GPIO_Init(void) {
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
}

/**
  * @brief  Initialize servo motors
  */
void Servo_Init(void) {
    // Initialize PWM channels for servos
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  // Azimuth servo
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);  // Elevation servo

    // Set initial position to stopped
    TIM3->CCR1 = PWM1_STOP;
    TIM3->CCR2 = PWM2_STOP;
}

/**
  * @brief  Error handler function
  */
void Error_Handler(void) {
    // Turn on error LED if available

    // Stop all motors for safety
    if (htim3.Instance != NULL) {
        TIM3->CCR1 = PWM1_STOP;
        TIM3->CCR2 = PWM2_STOP;
    }

    // Send error message if UART is available
    char error_msg[] = "ERROR: System halted due to critical error!\r\n";
    if (huart3.Instance != NULL) {
        HAL_UART_Transmit(&huart3, (uint8_t *)error_msg, strlen(error_msg), HAL_MAX_DELAY);
    }

    // Halt system
    __disable_irq();
    while (1) {
        // Blink error LED or similar indication
        HAL_Delay(500);
    }
}

void reset_elevation_to_zero(void) {
    float current_elevation;
    float error;
    uint32_t servo_pwm = PWM2_STOP;
    bool aligned = false;
    uint32_t timeout_counter = 0;  // Add timeout for safety

    snprintf(msg, sizeof(msg), "Setting elevation to 90°...\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    // Wait for stabilization before starting alignment
    HAL_Delay(500);

    // Get initial elevation
    if (HAL_OK == lis2mdl_read_all_axes() && HAL_OK == lis3dh_read_all_axes()) {
        apply_accel_calibration();
        current_elevation = calculate_accelerometer_elevation(x_accel, y_accel, z_accel);

        while (!aligned && timeout_counter < 300) { // Add timeout (30 seconds)
            error = 90.0f - current_elevation; // Target is 90 degrees

            // Normalize error to shortest path
            if (error > 180.0f) error -= 360.0f;
            if (error < -180.0f) error += 360.0f;

            if (fabs(error) < THRESHOLD) {
                servo_pwm = PWM2_STOP;
                aligned = true;
                // Add a stabilization pause when we first reach the threshold
                TIM3->CCR2 = PWM2_STOP;
                HAL_Delay(300); // Pause to let the system stabilize
            }
            else if (fabs(error) < THRESHOLD * 1.5) {
                // Use more gentle adjustment with progressive scaling near the target
                float adjustment_factor = fabs(error) / (THRESHOLD * 1.5); // 0-1 scale
                uint32_t adjustment = (uint32_t)(20 + 30 * adjustment_factor); // Scale between 20-50

                if (error > 0) {
                    servo_pwm = PWM2_STOP + adjustment; // Gentler adjustment
                } else {
                    servo_pwm = PWM2_STOP - adjustment; // Gentler adjustment
                }
            }
            else if (fabs(error) < THRESHOLD * 3) {
                // Medium correction for errors further out but not extreme
                if (error > 0) {
                    servo_pwm = PWM2_STOP + 70; // Medium adjustment
                } else {
                    servo_pwm = PWM2_STOP - 70; // Medium adjustment
                }
            }
            else if (error > 0) {
                servo_pwm = PWM2_CW; // Full speed when far from target
            } else {
                servo_pwm = PWM2_CCW; // Full speed when far from target
            }

            TIM3->CCR2 = servo_pwm;

            snprintf(msg, sizeof(msg), "Aligning elevation: Current=%.2f°, Error=%.2f°, PWM=%lu\r\n",
                     current_elevation, error, (unsigned long)servo_pwm);
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

            HAL_Delay(100);

            // Re-read sensors
            lis2mdl_read_all_axes();
            lis3dh_read_all_axes();
            apply_mag_calibration();
            apply_accel_calibration();
            current_elevation = calculate_accelerometer_elevation(x_accel, y_accel, z_accel);

            // If we've been very close to the target for several cycles, consider it aligned
            static int close_count = 0;
            if (fabs(error) < THRESHOLD * 1.2) {
                close_count++;
                if (close_count >= 5) { // If we've been close for ~0.5 seconds
                    servo_pwm = PWM2_STOP;
                    aligned = true;
                }
            } else {
                close_count = 0; // Reset counter if we drift away
            }

            timeout_counter++;
        }

        // After exiting loop, ensure motor is stopped
                TIM3->CCR2 = PWM2_STOP;
                HAL_Delay(500); // Final stabilization delay

                if (aligned) {
                    snprintf(msg, sizeof(msg), "Elevation aligned to 90°! Current: %.2f°\r\n", current_elevation);
                } else {
                    snprintf(msg, sizeof(msg), "Elevation alignment timeout. Best position: %.2f°\r\n", current_elevation);
                }
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            } else {
                snprintf(msg, sizeof(msg), "Failed to read sensor data for elevation reset.\r\n");
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            }

            // Stabilization delay
            HAL_Delay(1000);
        }



/**
  * @brief  Main function
  */
int main(void) {
    // Initialize HAL
    HAL_Init();

    // Configure system clock
    SystemClock_Config();

    // Initialize peripherals
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_I2C1_Init();
    MX_TIM1_Init();
    MX_TIM3_Init();
    MX_USART2_UART_Init();
    MX_USART3_UART_Init();

    // Initialize servo motors
    Servo_Init();

    // Wait for peripherals to stabilize
    HAL_Delay(500);

    // Display welcome message
    snprintf(msg, sizeof(msg), "\r\n\r\nMagnetometer-based Tracking System\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    snprintf(msg, sizeof(msg), "==============================\r\n");
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

    // Scan I2C bus to detect connected devices
    scan_i2c_bus();

    // Initialize variables
    HAL_StatusTypeDef status;
    uint8_t init_attempt = 0;
    bool lis2mdl_initialized = false;
    bool lis3dh_initialized = false;
    uint32_t last_recovery_time = 0;



    // Initialize LIS3DH accelerometer

    while (!lis3dh_initialized && init_attempt < 3) {
        snprintf(msg, sizeof(msg), "\r\nInitializing LIS3DH accelerometer (attempt %d/3)...\r\n", init_attempt + 1);
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

        status = lis3dh_init();

        if (status == HAL_OK) {
            lis3dh_initialized = true;
            snprintf(msg, sizeof(msg), "LIS3DH initialized successfully\r\n");
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        } else {
            snprintf(msg, sizeof(msg), "LIS3DH initialization failed! Error code: %d\r\n", status);
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            // Wait before next attempt
            HAL_Delay(500);
            init_attempt++;
        }
    }

    init_attempt = 0;

    // Initialize LIS2MDL magnetometer with retry
    while (!lis2mdl_initialized && init_attempt < 3) {
        snprintf(msg, sizeof(msg), "\r\nInitializing LIS2MDL magnetometer (attempt %d/3)...\r\n", init_attempt + 1);
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

        status = lis2mdl_init();

        if (status == HAL_OK) {
            lis2mdl_initialized = true;
            snprintf(msg, sizeof(msg), "LIS2MDL initialized successfully\r\n");
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

            // Perform automated magnetometer calibration
            snprintf(msg, sizeof(msg), "\r\nStarting automated calibration...\r\n");
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            calibrate_system();

            // Find and store magnetic north reference
            north_reference_angle = find_magnetic_north();

            // Align to north first
            align_to_north();

            // Now set the target to 90 degrees from north
            float target_azimuth = DESIRED_ANGLE1; // This will be directly 90° from north
            pid_azimuth.setpoint = target_azimuth;

        } else {
            snprintf(msg, sizeof(msg), "LIS2MDL initialization failed! Error code: %d\r\n", status);
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

            // Wait before next attempt
            HAL_Delay(500);
            init_attempt++;
        }
    }

    // Continue only if both sensors are initialized
    if (!lis2mdl_initialized) {
        snprintf(msg, sizeof(msg), "\r\nFailed to initialize LIS2MDL. Check connections!\r\n");
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        // Could continue with only accelerometer, but less accurate
    }

    // First, calibrate elevation if accelerometer is initialized
    if (lis3dh_initialized) {
        // Update gravity reference first
        snprintf(msg, sizeof(msg), "\r\nFinding gravity reference...\r\n");
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
        gravity_reference_elevation = find_elevation_gravity();

        // Reset elevation to 90 degrees and ensure it's stable
        reset_elevation_to_zero();  // This function targets 90 degrees
        HAL_Delay(500); // Allow time to stabilize
    }

    // Then handle magnetometer calibration with properly positioned box
        if (lis2mdl_initialized) {
            // Perform a single calibration after box is positioned
            snprintf(msg, sizeof(msg), "\r\nStarting magnetometer calibration...\r\n");
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            calibrate_system();

            // Find north reference after calibration
            snprintf(msg, sizeof(msg), "\r\nLocating magnetic north reference...\r\n");
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            north_reference_angle = find_magnetic_north();

            // Align to north first
            align_to_north();

            // Then rotate to desired target
            float target_angle = DESIRED_ANGLE1;
            float current_pos;
            rotate_to_desired_angle(target_angle, &current_pos);

            // Ensure mast stops completely before continuing
            TIM3->CCR1 = PWM1_STOP;
            HAL_Delay(500);
        } // Remove the extra closing brace here

        // Initialize PID controllers with better tuned values
        PID_Init(&pid_azimuth, 0.05f, 0.001f, 0.01f, DESIRED_ANGLE1, MAX_INTEGRAL);
        PID_Init(&pid_elevation, 0.01f, 0.001f, 0.001f, 90.0f, MAX_INTEGRAL); // 90 degrees elevation

    // Target positions for tracking demo
    float target_azimuth = DESIRED_ANGLE1; // Use the defined angle
    float target_elevation = 90.0f; // 90 degrees to be parallel to ground
    // Update PID setpoints
    pid_azimuth.setpoint = target_azimuth;
    pid_elevation.setpoint = target_elevation;

    // Main control variables
    uint32_t servo_pwm_azimuth = PWM1_STOP;
    uint32_t servo_pwm_elevation = PWM2_STOP;
    float error_azimuth = 0.0f;
    float error_elevation = 0.0f;

    snprintf(msg, sizeof(msg), "\r\nStarting tracking system. Target: Azimuth=%.1f°, Elevation=%.1f°\r\n\r\n",
             target_azimuth, target_elevation);
    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
    // Main control loop
    while (1) {
        // Read accelerometer data
        if (lis3dh_initialized) {
            status = lis3dh_read_all_axes();
            if (status == HAL_OK) {
            	apply_accel_calibration();
                status = lis3dh_read_temperature();
            }

            if (status != HAL_OK) {
                snprintf(msg, sizeof(msg), "LIS3DH communication error: %d\r\n", status);
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
                lis3dh_initialized = false;  // Mark as failed to trigger re-init later
            }
        }

        // Read magnetometer data
        if (lis2mdl_initialized) {
            status = lis2mdl_read_all_axes();
            if (status == HAL_OK) {
                status = lis2mdl_read_temperature();

                // Apply calibration to raw readings
                apply_mag_calibration();
            }

            if (status != HAL_OK) {
                snprintf(msg, sizeof(msg), "LIS2MDL communication error: %d\r\n", status);
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

                // Attempt recovery every 5 seconds
                uint32_t current_time = HAL_GetTick();
                if (current_time - last_recovery_time > 5000) {
                    snprintf(msg, sizeof(msg), "Attempting to recover magnetometer...\r\n");
                    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

                    status = lis2mdl_init();
                    if (status == HAL_OK) {
                        snprintf(msg, sizeof(msg), "Magnetometer recovered successfully\r\n");
                        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
                        lis2mdl_initialized = true;
                    } else {
                        lis2mdl_initialized = false;
                    }

                    last_recovery_time = current_time;
                }
            }
        }

        // Display sensor data
        snprintf(msg, sizeof(msg), "Accelerometer: X=%.3fg, Y=%.3fg, Z=%.3fg, T=%.1f°C\r\n",
                 x_accel, y_accel, z_accel, lis3dh_temp);
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

        if (lis2mdl_initialized) {
            snprintf(msg, sizeof(msg), "Magnetometer: X=%.4fG, Y=%.4fG, Z=%.4fG, T=%.1f°C\r\n",
                     x_mag, y_mag, z_mag, lis2mdl_temp);
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

            // Calculate current orientation angles
            float raw_azimuth = calculate_magnetometer_azimuth(x_mag, y_mag, z_mag);
            float current_azimuth = filter_angle(raw_azimuth);
            float current_elevation = calculate_accelerometer_elevation(x_accel, y_accel, z_accel);

            // For servo1 (azimuth - MAST motor)
            float pid_output_azimuth = PID_Compute(&pid_azimuth, current_azimuth, &error_azimuth);
            servo_pwm_azimuth = Calculate_Servo_PWM(error_azimuth, pid_output_azimuth, PWM1_STOP, PWM1_CW, PWM1_CCW);

            // Inside the main control loop:
            static uint32_t elevation_error_duration = 0;
            static const uint32_t ELEVATION_RESET_THRESHOLD = 30; // 3 seconds (at 100ms loop)

            if (fabs(current_elevation - 90.0f) > THRESHOLD * 2) {  // Changed from 0 to 90
                elevation_error_duration++;
                if (elevation_error_duration > ELEVATION_RESET_THRESHOLD) {
                    // Elevation has been far from 90 for too long - force a reset
                    snprintf(msg, sizeof(msg), "Elevation deviation detected (%.1f°). Forcing reset.\r\n", current_elevation);
                    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

                    reset_elevation_to_zero();  // This now resets to 90 degrees
                    elevation_error_duration = 0; // Reset the counter

                    // Re-read position after reset
                    lis2mdl_read_all_axes();
                    lis3dh_read_all_axes();
                    apply_mag_calibration();
                    current_elevation = calculate_accelerometer_elevation(x_accel, y_accel, z_accel);
                }
            } else {
                elevation_error_duration = 0; // Reset counter when within threshold
            }
            // For servo2 (elevation - BOX motor)
            float pid_output_elevation = PID_Compute(&pid_elevation, current_elevation, &error_elevation);
            servo_pwm_elevation = Calculate_Servo_PWM(error_elevation, pid_output_elevation, PWM2_STOP, PWM2_CW, PWM2_CCW);

            if (fabs(error_elevation) < THRESHOLD * 0.5) {
                servo_pwm_elevation = PWM2_STOP;
            }

            snprintf(msg, sizeof(msg), "Current orientation: Azimuth=%.1f°, Elevation=%.1f°\r\n",
                     current_azimuth, current_elevation);
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);


            snprintf(msg, sizeof(msg), "PID values: Azimuth(Err=%.1f°, Out=%.1f), Elevation(Err=%.1f°, Out=%.1f)\r\n",
                     error_azimuth, pid_output_azimuth, error_elevation, pid_output_elevation);
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);



            // Check if motion limits are exceeded (using accelerometer)
            bool motion_limits_ok = true;
            if (lis3dh_initialized) {
                motion_limits_ok = check_motion_limits(x_accel, y_accel, z_accel);
            }

            // Apply servo outputs if motion is within limits
            if (motion_limits_ok) {
                TIM3->CCR1 = servo_pwm_azimuth;
                TIM3->CCR2 = servo_pwm_elevation;

                snprintf(msg, sizeof(msg), "Servo outputs: Azimuth=%lu, Elevation=%lu\r\n",
                         (unsigned long)servo_pwm_azimuth, (unsigned long)servo_pwm_elevation);
            } else {
                // Gradually slow down instead of sudden stop
                uint32_t limited_pwm1 = (servo_pwm_azimuth + PWM1_STOP) / 2;
                uint32_t limited_pwm2 = (servo_pwm_elevation + PWM2_STOP) / 2;

                TIM3->CCR1 = limited_pwm1;
                TIM3->CCR2 = limited_pwm2;

                snprintf(msg, sizeof(msg), "MOTION LIMITS EXCEEDED! Reduced outputs: Azimuth=%lu, Elevation=%lu\r\n",
                         (unsigned long)limited_pwm1, (unsigned long)limited_pwm2);
            }
            HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

            // Check if we've reached the target
            bool azimuth_on_target = is_at_setpoint(current_azimuth, target_azimuth, THRESHOLD);
            bool elevation_on_target = is_at_setpoint(current_elevation, target_elevation, THRESHOLD);

            if (azimuth_on_target && elevation_on_target) {
                snprintf(msg, sizeof(msg), "STATUS: TARGET LOCKED!\r\n");
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            } else if (azimuth_on_target) {
                snprintf(msg, sizeof(msg), "STATUS: AZIMUTH ALIGNED, ADJUSTING ELEVATION...\r\n");
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            } else if (elevation_on_target) {
                snprintf(msg, sizeof(msg), "STATUS: ELEVATION ALIGNED, ADJUSTING AZIMUTH...\r\n");
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            } else {
                snprintf(msg, sizeof(msg), "STATUS: TRACKING IN PROGRESS...\r\n");
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            }
            } else {
            // If magnetometer is not available, try to recover it
            if (!lis2mdl_initialized) {
                // Attempt recovery every 5 seconds
                uint32_t current_time = HAL_GetTick();
                if (current_time - last_recovery_time > 5000) {
                    snprintf(msg, sizeof(msg), "Attempting to recover magnetometer...\r\n");
                    HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

                    // Scan I2C bus to check if device is present
                    scan_i2c_bus();

                    status = lis2mdl_init();
                    if (status == HAL_OK) {
                        lis2mdl_initialized = true;
                        snprintf(msg, sizeof(msg), "Magnetometer recovered successfully!\r\n");
                        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
                    } else {
                        snprintf(msg, sizeof(msg), "Magnetometer recovery failed.\r\n");
                        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
                    }

                    last_recovery_time = current_time;
                }

                // In magnetometer failure mode, stop servo movement for safety
                TIM3->CCR1 = PWM1_STOP;
                TIM3->CCR2 = PWM2_STOP;

                snprintf(msg, sizeof(msg), "STATUS: SYSTEM HALTED - WAITING FOR MAGNETOMETER\r\n");
                HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
            }
        }

        // Add delimiter between iterations for readability
        snprintf(msg, sizeof(msg), "-------------------------------\r\n\r\n");
        HAL_UART_Transmit(&huart3, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

        // Reduced delay for more responsive control
        HAL_Delay(100);
    }

    // This point should never be reached due to the infinite loop
    return 0;
    }


#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) {
    // Send debug message if UART is initialized
    if (huart3.Instance != NULL) {
        char assert_msg[100];
        snprintf(assert_msg, sizeof(assert_msg), "Assert failed: %s, line %lu\r\n", file, (unsigned long)line);
        HAL_UART_Transmit(&huart3, (uint8_t *)assert_msg, strlen(assert_msg), HAL_MAX_DELAY);
    }

    // Call error handler
    Error_Handler();
}
#endif
